print("hello world, i am learing python")
print("my name is abdulraheem")
print("today is good")
print("i am a boy")
name ="omowunmi"
print (name)
print("my name is "+name)
print("my name is"+ " "+name)

print(f"Hello {name}")