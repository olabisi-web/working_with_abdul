# Tast 1
full_name ="Oladeji Aminat Olabisi"
university ="Olabisi Onabanjo University"
local_govt_area ="Abeokuta South"
favorite_food ="Rice"
print(f"{full_name}\n{university}\n{local_govt_area}\n{favorite_food}\n")


# Tast 2
name = "Oladeji Aminat Olabisi"
state_of_origin = "ogun state"
print("Name:",name)
print(f"State_of_origin:", {state_of_origin})

# Tast 3
print("Monday\nTuesday\nWednesday\nThursday\nFriday\n")
print("Monday\tTuesday\tWednesday\tThursday\tFriday\t")


# Tast 4
name = "Oladji Aminat Olabisi"
your_class = "Python Practice"
your_best_subject = "Programing"
print(f"")