# task1
# user input and converted to lower
user_input = input("Enter your favour quote:") # collect n input from user
print(f"\"{user_input}\"")
# task_2
list1 = ("Enter your shopping item") # collecte input
list2 =  input("Enter your shopping item:") # collecte input
list3 = input("Ener your shopping item:") # collect input
# add to shopping_item
shopping_item = (list1)
shopping_item = (list2)
shopping_item = (list3)
# display
print(",".join(add_list))
# task_3
print("welcome to ojo place")
review_cus = input("kindly leave a reviem")
print(len(review_cus))
# task_4
user_input = input("kindly enter five name")
input_spilt = user_input.lower().split("")
input_spilt.sort()
for names in input_spilt:
    print (name)


